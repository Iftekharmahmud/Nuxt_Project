</<template>
    <div>
   <!--<h1>posts/{{$route.params.id}}</h1>-->
   <h1>posts route</h1>

</div>
        
</template>
<script>
export default{

}

</script>