<template>
  <section class="container">
  
    <h1>Welcome</h1>
    <table>
       <tr>
    <th>Name</th>
    <th>Email</th>
     </tr>
      <tr>
    <td>{{ name }}</td>
    <td></td>
  </tr>
  

   <!-- <h1>{{ this.$route.params.names }}</h1>-->
    
    <!--<h1>{{ this.$route.params.c }}</h1>-->
    </table>
  </section>
</template>

<script>
export default {
  data() {
    return {
      mydata: 'hello111',
      title: 'iftekhar',
      name: localStorage.getItem("Na"),
      email:''

    }
  },
 mounted() {
    
      this.name = this.$route.params.names;
     // this.email= this.$route.params.emails;
      localStorage.setItem("Na", name);
      console.log(localStorage.getItem("Na"));
       var nx=localStorage.getItem("Na");
      //localStorage.setItem("Em",email);

    
  },
    watch: {
    name(newName) {
      localStorage.name = newName;
    }
  }
}
</script>
<style>
table, th, td {
    border: 1px solid black;
}
</style>
